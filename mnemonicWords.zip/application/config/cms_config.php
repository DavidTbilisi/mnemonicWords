<?php
/**
 * Created by PhpStorm.
 * User: david
 * Date: 8/28/2018
 * Time: 10:17 AM
 */


$config['site_name'] = 'Learn words';
$config['author_name'] = 'GetSite.ge';
$config['author_url'] = 'http://getsite.ge/';