<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends Front_Controller{


	/**
	 * Welcome constructor.
	 */
	public function  __construct() {
		parent::__construct();
		$this->load->model('users_m');
		$this->load->model('words_m');

	}

	public function index()
	{


//		$words = csvToJson('assets/Phrasebook');
//		print_r($words);
//		die;
//		$this->output->enable_profiler(TRUE);
		$words = $this->words_m->get();
		$this->load->view('incs/header',["data"=>$this->data]);
		$this->load->view('read', ['words'=>$words]);
		$this->load->view('incs/footer');
	}

	public function wordsJson( $id = null ) {
		$words = $this->words_m->get($id);
		$this->output->set_content_type('application/json')
		             ->set_output(json_encode($words, JSON_UNESCAPED_UNICODE))->set_status_header(200);
	}

	public function routesToJson(  ) {
		$path = HOME."/assets/js/routes.json";
		// echo $path;
		file_put_contents($path,json_encode($this->router->routes));
	}


	public function save ($id = null) {
		$post=$this->input->post();
		if ($post['save']) {
			$data = array(
				'newWord'      => $post["newWord"],
				'assoc'        => $post["assoc"],
				'connection'   => $post["connection"],
				'meaning'      => $post["meaning"]
			);
			if ($id != null) {
				$this->words_m->save($data, $id);
			} else {
				$this->words_m->save($data);
			}
			echo 'saved';
			redirect(site_url());
		}
	}


	public function delete( $id ) {
		$this->words_m->delete($id);
		redirect(site_url());
	}

	public function  import(){
		$this->load->view('incs/header',["data"=>$this->data]);
		$this->load->view('import');
		$this->load->view('incs/footer');

	}

}
