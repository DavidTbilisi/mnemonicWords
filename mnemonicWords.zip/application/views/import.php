<form action="" enctype="multipart/form-data">
    <input type="file" name="file" required>
    <input type="submit" class="btn btn-primary">
</form>