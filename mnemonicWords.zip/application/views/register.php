<div class="login">
    <a class="btn btn-primary" href="<?php echo base_url('login') ?>"> შესვლა </a>

    <div class="login-block text-center">

        <form action="" method="post">
            <div class="form-group">
                <label for="email">Email address</label>
                <input type="email" class="form-control" id="email" aria-describedby="emailHelp"
                       placeholder="შეიყვანეთ ელ.ფოსტა" name="email">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" placeholder="შეიყვანეთ პაროლი" name="password">
            </div>

            <button type="submit" class="btn btn-primary">ანგარიშის შექმნა</button>
        </form>
    </div>
</div>



