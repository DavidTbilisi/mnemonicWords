<div class="instruction">

	<div class="text-block">

		<h1 class="title"><?=$this->lang->line('inst_title')?></h1>

		<p><b><?=$this->lang->line('inst_subtitle')?></b></p>
		<?=$this->lang->line('inst_text')?>


	</div>

</div>