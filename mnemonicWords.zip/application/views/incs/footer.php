</div> <?php // end of container ?>

<script src="//code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="//hammerjs.github.io/dist/hammer.min.js"></script>
<script src="<?php echo base_url('assets/js/bundle.js')?>"></script>

</body>
</html>