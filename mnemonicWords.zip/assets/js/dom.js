export function nthParent(element, len) {
    "use strict";
    let array = [];
    let leng = len === undefined ? 10 : len;
    let el = typeof element === 'object' ? element :
        document.querySelector(element);
    if (array.length === 0){array.push(el.parentElement)}
    while(array[array.length-1].parentElement && array.length < leng) {
        array.push(array[array.length-1].parentElement);
    }
    return array;
}