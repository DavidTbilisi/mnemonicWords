/**
 * Created by david on 8/26/2018.
 */
import 'jquery';
import 'hammerjs';
import '../css/main.scss';
require('./hammerJquery');
import {Ajax} from './Ajax';
import {nthParent} from './dom';
import {Url} from './url';
let url = new Url('mnemonicWords/index.php');

global.david = (function () {
    let view = (function () {

        return {
            editWord: $('.edit-word'),
            classEditable: 'editable',
            openNav: $('.open-nav span'),
            closeNav: $('.closebtn'),
            sideNav: $('.sidenav'),
            modal: $('#exampleModal .flex'),
        }
    })();

    let octopus = (function (v) {
        function toggleEditable(e) {
            e.preventDefault();
            let obj = {};
            let target = $(e.target);
            let parent = $(target).parent().parent();
            let siblings = $(parent).siblings();

            siblings.each(function (index, element) {
                if ($(element).hasClass(v.classEditable)) {

                    if ($(element).attr('contentEditable')) {
                        $(element).removeAttr('contentEditable');
                    } else {
                        $(element).attr('contentEditable', 'true');
                    }

                    let classname = $(element).attr('class');
                    classname = classname.split(' ')[0];
                    obj[classname] = $(element).text();
                }
            });

            return obj;
        }

        function edit(obj) {
            console.log(obj);
            $.post('index.php/edit/' + obj.id, obj).done(function (d) {
                console.log(d);
            });
        }




        function getSelectedText() {
            if (window.getSelection()) {
                return window.getSelection().toString();
            } else if (document.selection) {
                return document.selection.createRange().text;
            }
            return '';
        }

        $(v.editWord).on('click',function (e) {
            e.preventDefault();
            let target = e.target;
            let id = $(nthParent(target,2)[1]).data('id');

            let path = `${url.home()}/welcome/wordsJson/${id}`;
            let actionPath = `${url.home()}/save/${id}`;
            let formAction = nthParent(v.modal[0],1)[0];

            let ajax = new Ajax({url:path});

            ajax.ok.then(data => {
              let word = JSON.parse(data);
              $(formAction).attr('action',actionPath);
              $(v.modal).prepend(`<input hidden type="text" name="id" value="${word.id}">`);
              $(v.modal).find('input[name=newWord]').val(word.newWord);
              $(v.modal).find('input[name=assoc]').val(word.assoc);
              $(v.modal).find('input[name=connection]').val(word.connection);
              $(v.modal).find('input[name=meaning]').val(word.meaning);
            }).catch(err => console.log(err) )

        });



        $('ul').hammer().bind("panleft panright", function (e) {
            let element = nthParent(this,2);
            // d.l(element, e.type, e.gesture.center.y);
            if ( e.type == 'panleft' ) {
                $(element).find('.covered').css('display','flex');
            } else if (e.type == 'panright'){
                $(element).find('.covered').hide();
            }
        });


        return {nthParent,Ajax}
    })(view);

    return {view: view, octopus: octopus, Ajax}
})();
