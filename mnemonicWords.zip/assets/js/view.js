class View{
    constructor(){
        console.log('view inited');
    }
}