export class Controller {
    constructor() {
        console.log('class Controller inited');
    }
}